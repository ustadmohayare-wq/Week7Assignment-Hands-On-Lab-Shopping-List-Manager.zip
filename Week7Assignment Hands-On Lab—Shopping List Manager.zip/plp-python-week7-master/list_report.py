items = ["bread", "avocado", "milk", "sweet potatoes", "tea"]

# Print each item with its number
for i in range(len(items)):
    print(f"{i + 1}. {items[i]}")

# Count items with more than 4 letters
count = 0

for item in items:
    if len(item) > 4:
        count += 1

print("Items with more than 4 letters:", count)

# Find the longest item name
longest = items[0]

for item in items:
    if len(item) > len(longest):
        longest = item

print("Longest item:", longest)